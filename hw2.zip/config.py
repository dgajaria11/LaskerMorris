BLUE = "X"
ORANGE = "O"
EMPTY = None
